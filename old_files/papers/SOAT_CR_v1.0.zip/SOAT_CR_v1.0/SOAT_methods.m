% ----------------------------------------------------------------
% function SOAT_methods(
%                       I,            .... Input image
%                       x_final,      .... Thumbnail size in width
%                       y_final,      .... Thumbnail size in height
%                       SOAT_method)  .... SOAT thumbnailing transfor.
%                                           'CR': SOAT_CR.
% 
% This function contains SOAT thumbnailing transform functions:
% SOAT-CR: Cropping based function.
% 
% Jin Sun
% Temple University
% 2011
% ----------------------------------------------------------------

function SOAT_methods(I,x_final,y_final,SOAT_method)


if strcmp(SOAT_method,'CR')
%%%%%%%%%%%%%%%%%%%%%%%%%%% SOAT-CR %%%%%%%%%%%%%%%%%%%%%%%%%%% 
display(['*******SOAT-CR start:*******']);
% read saliency map
ImportanceIm=imread('SOAS.bmp');
% call cropping method
imout = auto_thumbnail(I, 0, ImportanceIm);
imoutResized=imresize(imout,[y_final x_final]);
imwrite(imoutResized,'SOAT_CR.jpg')
display(['*******SOAT-CR end:*******']);
end

end