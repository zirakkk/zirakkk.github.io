% ----------------------------------------------------------------
% function SOAS(
%                       I,                          .... Input image
%                       ViewingPixelInImage_X,      .... Thumbnail width shown on screen in pixel
%                       ViewingPixelInImage_Y,      .... Thumbnail height shown on screen in pixel                  
%                       ViewDistance                .... Viewing distance
%                       objectness_path)            .... Path to Objectness code
%                                                         
% 
% This function contains SOAS computation. A frequency domain filter is
% applied accordingly to the input image. Then a saliency map is computed
% on the filtered image.
% 
% Jin Sun
% Temple University
% 2011
% ----------------------------------------------------------------
function SOAS(I,ViewingPixelInImage_X,ViewingPixelInImage_Y,ViewDistance,objectness_path)


display('SOAS - Start computing...');

% call objectness calculation process
Iobjectness=SOAT_calObjectness(I,objectness_path);

% apply contrast sensitivity function as filter
viewed_I=SOAS_csfFilter(I,ViewingPixelInImage_X,ViewingPixelInImage_Y,ViewDistance);

viewed_I=mat2gray(viewed_I);
Iobjectness=mat2gray(Iobjectness);

viewed_I = Iobjectness.*viewed_I;

imwrite(viewed_I,'SOAS.bmp');



end