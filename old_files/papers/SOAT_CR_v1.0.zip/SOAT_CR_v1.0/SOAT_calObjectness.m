% ----------------------------------------------------------------
% function importancemap=SOAT_calObjectness(
%                       imgExample)                 .... Input image
%                       objectness_path)            .... Path to Objectness code
%                                                         
% 
% This function calls objectness routine to compute a collection of
% bounding boxes. Then an overall importance map is calculated.
% 
% Jin Sun
% Temple University
% 2011
% Revised: 1/2013, updated to Objectness V1.5
% ----------------------------------------------------------------

function importancemap=SOAT_calObjectness(imgExample,objectness_path)

updatePath;
numOfBoxes=1000;
boxToImageRatio=0.40;

importancemap=[];
% call the objectness routine

%1. set params
params = defaultParams(objectness_path);
params.sampling = 'nms';% new feature in objectness V1.5
%2. calculate sampled windows
boxes = runObjectness(imgExample,numOfBoxes,params);
% sort boxes according to their score
sort_boxes = sortrows(boxes,5);
top_boxes=[];

boxes_index=length(sort_boxes(:,1));top_boxes_index=1;
while boxes_index>0
    % discard small boxes
    if  (((sort_boxes(boxes_index,3)-sort_boxes(boxes_index,1))^2+(sort_boxes(boxes_index,4)-sort_boxes(boxes_index,2))^2) < (length(imgExample(:,1,1))^2+length(imgExample(1,:,1)).^2)*boxToImageRatio)
       top_boxes(top_boxes_index,:)=sort_boxes(boxes_index,:);
        top_boxes_index=top_boxes_index+1;
    end

    boxes_index=boxes_index-1;
end

importancemap(length(imgExample(:,1,1)),length(imgExample(1,:,1)))=0;
for it=1:length(top_boxes(:,1))
    i_start=fix(top_boxes(it,1)); i_end=fix(top_boxes(it,3));
    j_start=fix(top_boxes(it,2)); j_end=fix(top_boxes(it,4));
    importancemap(j_start:j_end,i_start:i_end)=importancemap(j_start:j_end,i_start:i_end)+top_boxes(it,5);
end

importancemap=mat2gray(importancemap);



    