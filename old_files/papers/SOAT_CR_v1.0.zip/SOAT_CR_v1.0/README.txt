IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING

By downloading, copying, installing or using the code, 
you agree with the following license claims:

COPYRIGHT (C) 2011, HAIBIN LING AND JIN SUN, ALL RIGHTS RESERVED.

REDISTRIBUTION AND USE IN SOURCE AND BINARY FORMS, WITH OR WITHOUT MODIFICATION,
ARE PERMITTED FOR NON-PROFIT RESEARCH USE ONLY, PROVIDED THAT THE FOLLOWING 
CONDITIONS ARE MET:

REDISTRIBUTION'S OF SOURCE CODE MUST RETAIN THE ABOVE COPYRIGHT NOTICE,
THIS LIST OF CONDITIONS AND THE FOLLOWING DISCLAIMER.

REDISTRIBUTION'S IN BINARY FORM MUST REPRODUCE THE ABOVE COPYRIGHT NOTICE,
THIS LIST OF CONDITIONS AND THE FOLLOWING DISCLAIMER IN THE DOCUMENTATION
AND/OR OTHER MATERIALS PROVIDED WITH THE DISTRIBUTION.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 

If you do not agree to this license agreement, 
do NOT download, install, copy or use the software. 

------------------------------------------------------------------------------------------------------
This code implements the Scale and Object Aware Thumbnailing (SOAT) algorithm in the following paper:
	
	J. Sun and H. Ling, Scale and Object Aware Image Thumbnailing, IJCV, to appear, 2013.
	
This code also borrows thumbnail cropping algorithm published in the following paper:

	B. Suh, H. Ling, B.B. Bederson, D.W. Jacobs,
	Automatic Thumbnail Cropping and Its Effectiveness,
	ACM UIST,
	2003.

The usage of this code is restricted for non-profit research usage only and using of the code is at the user's risk.

------------------------------------------------------------------------------------------------------
NOTES:
1. The algorithm requires following external software:
	a) Objectness: 
		http://groups.inf.ed.ac.uk/calvin/objectness/objectness-release-v1.5.tar.gz
		Function needed: runObjectness
		
		[Installation]
		1. Download the Objectness code package, extract it to 'libs/' folder such that 'runObjectness.m' file can be found at 'libs/objectness-release-v1.5/runObjectness.m'.
		2. Run the script in this directory 'adjustObjectness.sh' to compile and modify the Objectness code.
		
	b) Saliency computation: 
		Jonathan Harel, A Saliency Implementation in MATLAB: http://www.klab.caltech.edu/~harel/share/simpsal.zip
		Algorithm used:
		L. Itti, C. Koch, E. Niebur, A Model of Saliency-Based Visual Attention for Rapid Scene Analysis, IEEE Transactions on Pattern Analysis and Machine Intelligence, Vol. 20, No. 11, pp. 1254-1259, Nov 1998.
		Function needed: simpsal
		
		[Installation]
		Download and extract the code package to 'libs/Saliency' folder such that 'simpsal.m' file is at 'libs/Saliency/simpsal/simpsal.m'

2. Due to the dependency of Objectness code, this program is currently written for Linux platform.

3. The example usage of the code is demonstrated in 
		SOAT_demo.m

4. This code has been tested using Matlab 7.11.0 (R2010b 32-bit(glnx86)).

Author Contact Information:
	Haibin Ling (hbling at temple dot edu)
	Jin Sun (jinsun at cs dot umd dot edu)
	1/20/13
