#!/bin/bash

# compile the segment code
cd libs/objectness-release-v1.5/segment
make
cd ../../..

# change the dir_root in runObjectness.m file
find_text="dir_root = pwd"
replace_text="dir_root = [pwd \'libs\/objectness-release-v1.5\']"
sed -i s/"$find_text"/"$replace_text"/g libs/objectness-release-v1.5/runObjectness.m
