function M = SurroundInhibit( MInput, nIteration )

	%M=MInput;   return;

	%MInput = PreProcess(MInput);

	sz = size(MInput);
	imSize = min(sz);
	imSize = imSize/2;
	sigma_ex = 0.02*imSize;
	sigma_in = 0.25*imSize;
	c_ex = 0.5;
	c_in = 1.5;
	radius = round((imSize/2-0.5)/4);

	T=DoGFilter(sigma_ex,c_ex, sigma_in,c_in, radius);
	%figure(3); mesh(-radius:radius, -radius:radius, T);

	Cinh = 0.02;
    M = Scale(MInput, 0, 1);

	[nY,nX] = size(M);
	MM = zeros(nY+2*radius, nX+2*radius);
	MM(1+radius:nY+radius, 1+radius:nX+radius) = M;
	for iIt = 1:nIteration
		%iIt
        for k=1:radius
            MM(k,           radius+1:radius+nX) = MM(radius+1,  radius+1:radius+nX);	% TOP
    		MM(nY+radius+k, radius+1:radius+nX) = MM(nY+radius, radius+1:radius+nX);	% BOTTOM
        end
        for k=1:radius
            MM(:, k     	  ) = MM(:, radius+1);		% LEFT
            MM(:, nX+radius+k ) = MM(:, nX+radius);     % RIGHT
        end
		
		tmpM = conv2( MM, T );
		[n1,n2] = size(tmpM);
		MM = abs( MM + tmpM(radius+1:(n1-radius), radius+1:(n2-radius)) - Cinh );
		MM = Scale(MM, 0, 1);
    
		%figure(88); subplot(3,4,iIt); imshow(M); title(sprintf('%d iteration',iIt));
	end
	M = MM(1+radius:nY+radius, 1+radius:nX+radius);
    
    return
    
    
%-----------------------------------------
function imRes = PreProcess(imI)

	[nY,nX]=size(imI);    
	edgeY = max(round(nY/20),2);
	edgeX = max(round(nX/20),2);

    mask = ones(nY,nX);
	for x = 1:edgeX
		val = sqrt(x/edgeX);
		mask(:,x) = val * mask(:,x);
		mask(:,nX-x+1) = val * mask(:,nX-x+1);
	end

	for y = 1:edgeY
		val = y/edgeY;
		mask(y,:) = val * mask(y,:);
		mask(nY-y+1,:) = val * mask(nY-y+1,:);
	end

	imRes = imI;
	imRes = imRes.*mask;

	return;