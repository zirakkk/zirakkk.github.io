% function threshold = 
%   FindThres(imSaliEx, cropType, searchType, bDemo, filename)
%
%        searchType     : 1:gradient, 2:binary

function threshold = FindThres(imin, imSali, cropType, searchType, bKeepRatio)

    if ~exist('bKeepRatio')	     bKeepRatio = 0;     end
        
    %-Prepare for the auxMatrix
    [NY,NX] = size(imSali);
    auxSum  = imSali;
    for y=2:NY    auxSum(y,1:NX)=auxSum(y,1:NX)+auxSum(y-1,1:NX);   end
    for x=2:NX    auxSum(1:NY,x)=auxSum(1:NY,x)+auxSum(1:NY,x-1);   end

    %-Searching for the 'optimum threshold' as the must gradient position
    startSali       = 0.60;%0.6
    saliPer         = startSali:0.001:1.0;
    areaPer         = zeros(size(saliPer));
    nPer            = length(saliPer);
    areaPer(nPer)   = 1.0;
    areaTotal       = NY*NX;

    %-- Construct the function of Area-ratio to Sali-ratio
    for ii=nPer-1:-1:1
        if cropType == 0
            fprintf('%2d/%d ', ii, nPer-1);  if mod(nPer-ii,10)==0|ii==1 fprintf('\n'); end
            initArea=areaPer(ii+1)*areaTotal;
            [XRan,YRan] = cropping_BF(imSaliEx, saliPer(ii), auxSum, initArea, bKeepRatio);
        else
            [XRan,YRan] = Cropping_Heuristic(imSali, saliPer(ii),auxSum,bKeepRatio);
        end
        areaPer(ii) = double((XRan(2)-XRan(1)+1)*(YRan(2)-YRan(1)+1)) / areaTotal;
    end


    switch searchType
        
    case 1          % gradient
        %-- Find the maximum gradient
        [threshold, thresArea] = GradientSearch(saliPer, areaPer);
        
    case 2          % binary search
        %--"binary searching" for the proper threshold
        [threshold, thresArea, saliBin,areaBin] = BinarySearch(saliPer, areaPer, cropType);
    end

return


%---------------------------------------------------------------------
function [threshold, thresArea] = GradientSearch(saliPer, areaPer)
    %-- Find the maximum gradient
    diffArea = diff(areaPer);
    diffArea = diffArea(1:length(areaPer)-2);  % remove the last two, due to the margin result
    [maxDiff, threPos] = max(diffArea);
    threshold = saliPer(threPos);
    thresArea = areaPer(threPos);

%---------------------------------------------------------------------
function [threshold, thresArea, saliBin,areaBin] = BinarySearch(saliPer, areaPer, cropType)
    %--Initialize searching
    nPer    = length(saliPer);
    iLeft   = 1; 
    iRight  = nPer - 2;
    saliBin = [saliPer(iLeft), saliPer(iRight)];       
    areaBin = [areaPer(iLeft), areaPer(iRight)];       

    %--Binary searching
    iMid    = round(0.5*(iLeft+iRight));
    while iLeft < iRight-1  %abs(saliBin(iRight)-saliBin(iLeft)) > 0.01
        iMid    = round(0.5*(iLeft+iRight));
        areaMid = areaPer(iMid);
        saliMid = saliPer(iMid);
        saliBin = [saliBin, saliMid];
        areaBin = [areaBin, areaMid];

        if areaMid*2 > areaPer(iLeft)+areaPer(iRight)
            iRight = iMid;
        else
            iLeft  = iMid;
        end
    end
    
    %--Tune the result back toward a large gradient position
    if cropType==1      % Heuristic
        gradArea = diff(areaPer);
        while iMid>1 & gradArea(iMid)<gradArea(iMid-1)
            iMid = iMid - 1;
        end
        areaMid = areaPer(iMid);
        saliMid = saliPer(iMid);
        saliBin = [saliBin, saliMid];
        areaBin = [areaBin, areaMid];
    end        
    
    threshold = saliBin(length(saliBin));
    thresArea = areaBin(length(saliBin));