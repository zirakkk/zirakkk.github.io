% [XRan, YRan] = Cropping_Heuristic(imSaliency, ratio, auxSum)
%
function [XRan, YRan] = Cropping_Heuristic(imSaliency, ratio, auxSum, bKeepRatio)

if nargin<4        bKeepRatio   = 0;        end
if ~exist('auxSum')
    [NY,NX]=size(imSaliency);
    auxSum = imSaliency;
    for y=2:NY    auxSum(y,1:NX)=auxSum(y,1:NX)+auxSum(y-1,1:NX);   end
    for x=2:NX    auxSum(1:NY,x)=auxSum(1:NY,x)+auxSum(1:NY,x-1);   end
end

if bKeepRatio==1
    [XRan,YRan] = Cropping_Heuristic_KR(imSaliency, ratio, auxSum);
else
    threshold = sum(sum(imSaliency));
    threshold = threshold * ratio;

    [nY,nX]=size(imSaliency);
    radius = 3;
    imCur = imSaliency;

    XRan = round([nX/2-radius,nX/2+radius]);
    YRan = round([nY/2-radius,nY/2+radius]);
    imCur(YRan(1):YRan(2), XRan(1):XRan(2)) = 0;

    curSum = 0;
    count=0;
    while curSum < threshold
        %count=count+1
        %-- Find maximum saliency point
        [tmpMax,maxY] = max(imCur);
        [curMax,maxX] = max(tmpMax);
        maxY = maxY(maxX);
    
        %-- Update maxrent saliency sum
        [XRan,YRan]=UpdateRan(XRan,YRan,maxX-radius,maxY-radius);
        [XRan,YRan]=UpdateRan(XRan,YRan,maxX-radius,maxY+radius);
        [XRan,YRan]=UpdateRan(XRan,YRan,maxX+radius,maxY-radius);
        [XRan,YRan]=UpdateRan(XRan,YRan,maxX+radius,maxY+radius);
        [XRan,YRan]=RegulateRan(XRan,YRan,1,nX,nY);

        %XRan,YRan
        XRan = round(XRan);
        YRan = round(YRan);

        %curSum = sum(sum(imSaliency(YRan(1):YRan(2), XRan(1):XRan(2))));
        curSum = SumEx(imSaliency, auxSum, YRan(1),YRan(2), XRan(1),XRan(2));
        imCur(YRan(1):YRan(2), XRan(1):XRan(2)) = 0;
    end

    %XRan,YRan,radius,nX,nY
    [XRan,YRan]=RegulateRan(XRan,YRan,radius,nX,nY);
end

return;

%-------------------------------------------------------------------------------
function [XRan,YRan] = Cropping_Heuristic_KR(imSaliency, ratio, auxSum);

    threshold = sum(sum(imSaliency));
    threshold = threshold * ratio;

    [nY,nX]=size(imSaliency);
    radius = 3;
    imCur  = imSaliency;

    XRan = round([nX/2-radius,nX/2+radius]);
    YRan = round([nY/2-radius,nY/2+radius]);
    imCur(YRan(1):YRan(2), XRan(1):XRan(2)) = 0;

    curSum 	= 0;
    count	= 0;
    while curSum < threshold
        %count=count+1
        %-- Find maximum saliency point
        [tmpMax,maxY] = max(imCur);
        [curMax,maxX] = max(tmpMax);
        maxY = maxY(maxX);
    
        %-- Update maxrent saliency sum
        [XRan,YRan]=UpdateRan(XRan,YRan,maxX-radius,maxY-radius);
        [XRan,YRan]=UpdateRan(XRan,YRan,maxX-radius,maxY+radius);
        [XRan,YRan]=UpdateRan(XRan,YRan,maxX+radius,maxY-radius);
        [XRan,YRan]=UpdateRan(XRan,YRan,maxX+radius,maxY+radius);
        [XRan,YRan]=RegulateRan(XRan,YRan,1,nX,nY);

		%--Increase the rectangle to keep the aspect ratio
		%[XRan,YRan]=KeepRatio(XRan,YRan,nX,nY);
		xlen = XRan(2)-XRan(1);
		ylen = YRan(2)-YRan(1);
		if xlen/nX < ylen/nY			
			% increase in X direction
			dX	= ylen*nX/nY - xlen;
			if dX<0				keyboard;		end
			XRan(1) = max(XRan(1)-dX/2, 1);
			XRan(2) = min(XRan(2)+dX/2, nX);
			
		else
			% increase in Y direction
			dY	= xlen*nY/nX - ylen;
			if dY<0				keyboard;		end
			YRan(1) = max(YRan(1)-dY/2, 1);
			YRan(2) = min(YRan(2)+dY/2, nY);
		end

		%--Calculate current sum of saliency
        XRan = round(XRan);
        YRan = round(YRan);
        %curSum = sum(sum(imSaliency(YRan(1):YRan(2), XRan(1):XRan(2))));
        curSum = SumEx(imSaliency, auxSum, YRan(1),YRan(2), XRan(1),XRan(2));
        imCur(YRan(1):YRan(2), XRan(1):XRan(2)) = 0;
    end

    %XRan,YRan,radius,nX,nY
    [XRan,YRan]=RegulateRan(XRan,YRan,radius,nX,nY);
return;

%-----------------------------------------------
function [XRan,YRan] = UpdateRan(XRan,YRan,maxX,maxY);
    if (maxY > YRan(2))
        YRan(2) = maxY;
    elseif maxY < YRan(1);
        YRan(1) = maxY;
    end
    if maxX > XRan(2)
        XRan(2) = maxX;
    elseif maxX < XRan(1);
        XRan(1) = maxX;
    end

%-----------------------------------------------
function [XRan,YRan]=RegulateRan(XRan,YRan,edge,nX,nY)
    XRan(1) = max(XRan(1),edge); 	XRan(2)=min(XRan(2),nX-edge+1);
    YRan(1) = max(YRan(1),edge); 	YRan(2)=min(YRan(2),nY-edge+1);

%-----------------------------------------------
function sumRes = SumEx( data, auxSum,nStartY,nEndY,nStartX,nEndX)
    if nStartX==1 | nStartY==1
        sumRes = sum(sum(data(nStartY:nEndY,nStartX:nEndX)));
    else
        sumRes = auxSum(nEndY,nEndX) + auxSum(nStartY-1,nStartX-1) ...
                 - auxSum(nStartY-1,nEndX) - auxSum(nEndY,nStartX-1);
    end
    return;
