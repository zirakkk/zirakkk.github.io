function imRes = CompIntensityConspicuity( imIn )

%    imIn = imread('17.jpg');

    MAXLEVEL = 8;
    im = double(imIn)/255.0;
    imIntensity = (im(:,:,1)+im(:,:,2)+im(:,:,3))/3.0;  % according Itti's paper

    %--Calculate Gaussian pyramid
    IPyramid = GaussianPyramid( imIntensity, MAXLEVEL );
    
    %--Calculate intensity contrasts (Features)
    count = 6;
    IContrasts = cell(1,count);
    ii    = 1;
    for c=2:4
        for s=3:4
            IContrasts{ii} = abs( IPyramid{c} - ...
                                  imresize(IPyramid{c+s},size(IPyramid{c}),'nearest'));

            %--Non-classical surround inhibition iterations
            %figure(9); subplot(2,count,2*ii-1); imshow(IContrasts{ii}); Title('Before Inhibition');
            IContrasts{ii} = SurroundInhibit( IContrasts{ii}, 10 );
            %figure(9); subplot(2,count,2*ii); imshow(IContrasts{ii}); Title('After Inhibition');

            ii = ii+1;
        end
    end

    %--Combine the features into one conspicuity feature map
    sz = round(size(imIntensity)/4);
    imRes = zeros(sz);
    for ii=1:count
        imRes = imRes + imresize(IContrasts{ii},sz,'nearest');
    end
    imRes = imRes / count;
    imRes = Scale(imRes, 0, 1);
    imRes = SurroundInhibit( imRes, 10 );
    imRes = Scale(imRes, 0, 1);

return;

%------------------------------------------------------
% Following code is for debug only, no use now
iFigure=6;

figure(iFigure); clf;
subplot(1,3,1);     imshow(im);             title 'Original'
subplot(1,3,2);     imshow(imIntensity);    title 'Intensity (V)'
subplot(1,3,3);     imshow(imRes);          title 'Intensity Contrast'


return;