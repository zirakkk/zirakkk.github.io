% function imRes = Cropping(im, XRanRatio, YRanRatio, typeFormat)
%
%   typeFormat  0   : clipping out and get the thumbnail
%               1   : let the surround be black
%               2   : draw a white line along the clipping rectangle
%               3   : let the surround be darker

function imRes = Cropping(im, XRanRatio, YRanRatio, typeFormat)

%--Dealing with input arguments
switch nargin
case 3
    typeFormat = 0;     % clipping out and get the thumbnail
end

typeFormat = max(typeFormat,0);

%--Compute the clippig ranges
[M,N,C] = size(im);
XRan = round(XRanRatio*N);
YRan = round(YRanRatio*M);
XRan(1)=max(XRan(1),1); XRan(2)=min(XRan(2),N);
YRan(1)=max(YRan(1),1); YRan(2)=min(YRan(2),M);

%--Cropping
switch typeFormat
case 0      % clipping out and get the thumbnail
    imRes = im( YRan(1):YRan(2), XRan(1):XRan(2), :);
        
case 1      % let the surround be black
    imRes = im;
    imRes( 1:YRan(1)-1, :, :) = 0;
    imRes( YRan(2)+1:M, :, :) = 0;
    imRes( :, 1:XRan(1)-1, :) = 0;
    imRes( :, XRan(2)+1:N, :) = 0;

    imRes( YRan(1), :, :) = 1;
    imRes( YRan(2), :, :) = 1;
    imRes( :, XRan(1), :) = 1;
    imRes( :, XRan(2), :) = 1;
    
case 2      % draw a white line along the clipping rectangle
    imRes = im;
    imRes( YRan(1), :, :) = 1;
    imRes( YRan(2), :, :) = 1;
    imRes( :, XRan(1), :) = 1;
    imRes( :, XRan(2), :) = 1;
    
case 3      % let the surround be darker
    imRes = im;
    imRes( 1:YRan(1)-1, :, :) = uint8(0.5*double(imRes( 1:YRan(1)-1, :, :)));
    imRes( YRan(2)+1:M, :, :) = uint8(0.5*double(imRes( YRan(2)+1:M, :, :)));
    imRes( :, 1:XRan(1)-1, :) = uint8(0.5*double(imRes( :, 1:XRan(1)-1, :)));
    imRes( :, XRan(2)+1:N, :) = uint8(0.5*double(imRes( :, XRan(2)+1:N, :)));
end

