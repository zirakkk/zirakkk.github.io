#include "mex.h"

/*---------------------------------------------------------------------*/
double sum(double *pSali, int M, int N, 
           int yStart, int yEnd, int xStart, int xEnd)
{
    double  res=0.0;
    double  *pCur;
    int     y, x, k;
    int     nWidth = xEnd - xStart + 1;
    for(y=yStart; y<=yEnd; y++)
    {   
        pCur = pSali + y*N + xStart;
    
        for(k=0; k<nWidth; k++)   {
            res += *pCur;
            pCur ++;
        }
    }
    return res;
}

/*---------------------------------------------------------------------*/
double sumEx(double *pAuxSum, int M, int N, 
           int yStart, int yEnd, int xStart, int xEnd)
{
    double  res=0.0;
    if(xStart==0 || yStart==0)    {
        res = *(pAuxSum + yEnd*N + xEnd);
    }
    else if(xStart==0)  {
        res = *(pAuxSum + yEnd*N + xEnd) -
              *(pAuxSum + (yStart-1)*N + xEnd);
    }
    else if(yStart==0)  {
        res = *(pAuxSum + yEnd*N + xEnd) -
              *(pAuxSum + yEnd*N + xStart - 1);
    }
    else    {
        res = *(pAuxSum + yEnd*N + xEnd) -
              *(pAuxSum + yEnd*N + xStart - 1) -
              *(pAuxSum + (yStart-1)*N + xEnd) +
              *(pAuxSum + (yStart-1)*N + xEnd - 1);
    }
    return res;
}

/*---------------------------------------------------------------------*/
void Cropping_BF(double *pSali, double *pAuxSum,
                 double dRatio, int M, int N, 
                 double *pXRange, double *pYRange)
{
    int     optXStart, optXEnd, optYStart, optYEnd;
    int     nStartX, nStartY, nEndX, nEndY;
    double  minArea, sumThreshold, curSum;
    bool    bNewResult;
    
    /* Initialize results   */
    optXStart = 0;      optXEnd   = N-1;
    optYStart = 0;      optYEnd   = M-1;
    bNewResult = false;
    minArea = M*N;

    /*sumThreshold = sum(pSali, M, N, 0, M-1, 0, N-1) * dRatio;*/
    sumThreshold = sumEx(pAuxSum, M, N, 0, M-1, 0, N-1) * dRatio;

    /* Search for new result, cornered at (nStartX,nStartY) */
    for(nStartY=1; nStartY<M-1; nStartY++)
    {
        /* printf("%3d/%d \n", nStartY, M); */
        for(nStartX=1; nStartX<N-1; nStartX++)
        {
            bNewResult = false;

            for(nEndY=nStartY+1; nEndY<M; nEndY++)
            {
                nEndX = (int)(minArea/(nEndY-nStartY+1)+0.5) + nStartX - 1;
                if(nEndX>=N)   nEndX = N-1;

                curSum = sum(pSali, M,N, nStartY,nEndY,nStartX,nEndX);
                while (curSum > sumThreshold)
                {
                    bNewResult  = true;
                    optXEnd     = nEndX;
                    optYEnd     = nEndY;
                    nEndX       = nEndX-1;
                    curSum      = sum(pSali, M,N, nStartY,nEndY,nStartX,nEndX);
                }
            
                if(bNewResult)
                {
                    optXStart = nStartX;
                    optYStart = nStartY;
                    minArea = (optXEnd-optXStart+1)*(optYEnd-optYStart+1);
                }
            }
        }
    }

    /* return result */
    pXRange[0] = optXStart+1;
    pXRange[1] = optXEnd+1;
    pYRange[0] = optYStart+1;
    pYRange[1] = optYEnd+1;
}

/*-----------------------------------------------------------------------
     [XRange, YRange] = Cropping_BruceForce(pSali, ratio)
 ------------------------------------------------------------------------*/
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    mxArray *pMxSali, *pMxRatio, *pMxAuxSum;
    mxArray *pMxXRange, *pMxYRange;
    double *pSali, *pRatio, dRatio, *pAuxSum;
    double *pXRange, *pYRange;
    int M,N;

    /* Prepare for the data */
    pMxSali     = prhs[0];
    pSali       = mxGetPr(pMxSali);
    M           = mxGetM(pMxSali);
    N           = mxGetN(pMxSali);
    pMxRatio    = prhs[1];
    pRatio      = mxGetPr(pMxRatio);
    dRatio      = *pRatio;
    pMxAuxSum   = prhs[2];
    pAuxSum     = mxGetPr(pMxAuxSum);

    /* Create output matrices */
    pMxXRange = mxCreateDoubleMatrix(1,2,mxREAL);
    pMxYRange = mxCreateDoubleMatrix(1,2,mxREAL);
    pXRange = mxGetPr(pMxXRange);
    pYRange = mxGetPr(pMxYRange);
    
    /* Cropping */
    Cropping_BF(pSali, pAuxSum, dRatio, M, N, pXRange, pYRange);

    /* Return */
    plhs[0] = pMxXRange;
    plhs[1] = pMxYRange;
}

