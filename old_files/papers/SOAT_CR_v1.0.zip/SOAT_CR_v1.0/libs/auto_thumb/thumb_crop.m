%---------------------------------------------------------------------------
% function [imIcon, imIconSali] = ...
%                     thumb_crop( imin, ...		% input image
% 								  imSali,	...		% saliency map of input image imin
%                                 cropType, ...   % 0:bruce force, 1:heuristic
%                                 threshold, ...	% if <0, then automatically determine the threshold
%                                 searchType, ... % 0:demo, 1:gradient, 2:binary
%                                 bKeepRatio, ...
%                                 incrEdge,...             
%                                 cropFormat, ...
%                                 iFigure)
%
%	This function cropping the imput image 'imin' to get an output image 'imIcon',
%	while 'imIconSali' contains the cropped saliency map.
%	
%	Haibin Ling (hbling@cs.umd.edu)
%	Department of Computer Science, University of Maryland, College Park
%	Dec. 2002
%
%---------------------------------------------------------------------------
function [imIcon, imIconSali] = ...
                    thumb_crop( imin, ...		% input image
								imSali,	...		% saliency map of input image imin
                                cropType, ...   % 0:bruce force, 1:heuristic
                                threshold, ...	% if <0, then automatically determine the threshold
                                searchType, ... % 0:demo, 1:gradient, 2:binary
                                bKeepRatio, ...
                                incrEdge,...             
                                cropFormat, ...
                                iFigure)

    %--Dealing with default parameters
    if ~exist('iFigure')       	iFigure      = -1;       			end
    if ~exist('incrEdge')      	incrEdge     = [.03,.03,.03,.03]; 	end
    if ~exist('bKeepRatio')		bKeepRatio   = 0;        			end
    if ~exist('cropFormat')  	cropFormat   = 0;        			end
    if ~exist('searchType')		searchType   = 1;        			end
    if ~exist('threshold')		threshold    = -1;       			end
    if ~exist('cropType')		cropType     = 1;        			end

    imSaliEx = PostProcesSaliencyMap(imSali);

    %-- Search for the cutting area
    bDynaThre = threshold < 0;
    if bDynaThre
        threshold  = FindThres(imin, imSaliEx, cropType, searchType, bKeepRatio);
    end

	%-- Searching for cropping rectangle
    [NY,NX] = size(imSaliEx);
    auxSum  = imSaliEx;
    for y=2:NY    auxSum(y,1:NX)=auxSum(y,1:NX)+auxSum(y-1,1:NX);   end
    for x=2:NX    auxSum(1:NY,x)=auxSum(1:NY,x)+auxSum(1:NY,x-1);   end
    
    switch cropType
    case 0      % Brute force
        [XRan,YRan] = cropping_BF(imSaliEx, threshold, auxSum, -1, bKeepRatio);
    case 1      % Heuristic
        [XRan,YRan] = Cropping_Heuristic(imSaliEx, threshold, auxSum, bKeepRatio);
    end
    
    imIconSali = imSaliEx(YRan(1):YRan(2),XRan(1):XRan(2),:);

    %-- Crop the image and get the icon
    sz      = size(imSaliEx);
    XRan    = double(XRan)/sz(2);    
    YRan    = double(YRan)/sz(1);    
    
    if bDynaThre | cropType==0
        XRan(1) = max(0.01,XRan(1)-incrEdge(1));
        XRan(2) = min(0.99,XRan(2)+incrEdge(2));
        YRan(1) = max(0.01,YRan(1)-incrEdge(3));
        YRan(2) = min(0.99,YRan(2)+incrEdge(4));
    end
    
    imIcon  	= Cropping(imin, XRan, YRan, cropFormat);
    imIconSali 	= Cropping(imSaliEx, XRan, YRan, cropFormat);
	
    %-- Demo output results if iFigure > 0
    if iFigure > 0
        figure(iFigure); clf;
        subplot(2,2,1);     imshow(imin);             	title 'Original'
        subplot(2,2,2);     imshow(imIcon);         	title 'Clipped Icon'
        subplot(2,2,3);     imshow(imSaliEx);         	title 'Sali Map'
        subplot(2,2,4);     imshow(imIconSali);     	title 'Clipped Sali Map'
        imwrite(imIcon, 'imIcon.jpg', 'JPEG');
        imSaliEx = min(imSaliEx*8,1);
        imwrite(imSaliEx, 'imSali.jpg', 'JPEG');
        imIconSali = min(imIconSali*8,1);
        imwrite(imIconSali, 'imIconC.jpg', 'JPEG');
    end