function imRes = CompOrientationConspicuity( imIn )

    %imIn = imread('im01_.jpg');

    MAXLEVEL = 8;
    im = double(imIn)/255.0;
    imIntensity = (im(:,:,1)+im(:,:,2)+im(:,:,3))/3.0;  % according Itti's paper

    %--Calculate Gabor orientation pyramid
    % EO = gaborconvolve(im,  nscale, norient, minWaveLength, mult, sigmaOnf, dThetaOnSigma)
    %
    %    nscale        = 4;     Number of wavelet scales.
    %    norient       = 6;     Number of filter orientations.
    %    minWaveLength = 3;     Wavelength of smallest scale filter.
    %    mult          = 2;     Scaling factor between successive filters.
    %    sigmaOnf      = 0.65;  Ratio of the standard deviation of the Gaussian describing the log Gabor
    %                           filter's transfer function in the frequency domain to the filter center 
    %                           frequency.
    %    dThetaOnSigma = 1.5;   Ratio of angular interval between filter orientations and the standard 
    %                           deviation of the angular Gaussian function used to construct filters in 
    %                           the freq. plane.

    nscale  = MAXLEVEL;
    norient = 4;
    orientPiry = gaborconvolve(imIntensity, nscale, norient, 3, 2, 0.65, 1.5);

    for j=1:norient             % This loop is used for debug, displaying the pyramid
        for i=1:nscale
            % imTmp = abs(orientPiry{i,j});   imTmp = scale(imTmp,0,1);
            % figure(3);  subplot(norient,nscale, (j-1)*nscale+i);  imshow(imTmp);
        end
    end


    %--Calculate orientation contrast
    sz = round(size(imIntensity)/4);
    count = 6;
    oriMaps = cell(norient, count);
    ii = 1;
    for c=2:4
        for s=3:4
            for ori=1:4
                oriMaps{ori, ii} = abs(abs(orientPiry{c,ori})-abs(orientPiry{c+s,ori}));
                oriMaps{ori, ii} = imresize(oriMaps{ori, ii}, sz, 'bilinear' );

                %figure(11); subplot(8,count,12*ori+2*ii-13); imshow(oriMaps{ori, ii}); Title('Before Inhibition');
                oriMaps{ori, ii} = SurroundInhibit( oriMaps{ori, ii}, 10 );
                %figure(11); subplot(8,count,12*ori+2*ii-12); imshow(oriMaps{ori, ii}); Title('After Inhibition');
            end
            ii = ii+1;
        end
    end


    %--Combine contrasts into conspicuities
    imRes = zeros(sz);
    conOri = cell(1,4);
    for ori=1:4
        conOri{ori} = zeros(sz);
    end
    for ori=1:4
        for ii=1:count
            conOri{ori} = conOri{ori} + oriMaps{ori,ii};
        end
        conOri{ori} = conOri{ori}/count;
        conOri{ori} = SurroundInhibit( conOri{ori}, 10 );
        imRes = imRes + conOri{ori};
    end

    imRes = imRes / 4;
    imRes = Scale(imRes, 0, 1);
    imRes = SurroundInhibit( imRes, 10 );
    %imRes = SurroundInhibit( imRes, 10 );

    return;
    %------------------------------------------------------
    % Following code is for debug only, no use now
    figure(7); clf;
    subplot(2,2,1);     imshow(im);         title 'Original'
    subplot(2,2,2);     imshow(imRes);      title 'Orientation Contrast'
    subplot(2,4,5);     imshow(conOri{1});      title 'Orientation 1'
    subplot(2,4,6);     imshow(conOri{2});      title 'Orientation 2'
    subplot(2,4,7);     imshow(conOri{3});      title 'Orientation 3'
    subplot(2,4,8);     imshow(conOri{4});      title 'Orientation 4'