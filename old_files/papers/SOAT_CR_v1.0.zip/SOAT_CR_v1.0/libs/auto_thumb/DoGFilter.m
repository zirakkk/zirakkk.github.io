% T = DoGFilter(sigma_ex,c_ex, sigma_in,c_in, width)
%
%   Compute the DoG filter used to inhibit surround stimuli in a contrast map
% before combine the map into conspicuity feature map.
%   
%   sigma_ex    :   para for extraction 
%   c_ex        :
%   sigma_in    :   para for inhibition
%   c_in        :
%   width       :   the width of the filter pattern expected
%

function T=DoGFilter(sigma_ex,c_ex, sigma_in,c_in, radius)

X = -radius:radius;
Y = X;

T = zeros(length(X),length(Y));

over_sigma_ex2 = 0.5/(sigma_ex*sigma_ex);
over_sigma_in2 = 0.5/(sigma_in*sigma_in);
para_ex = c_ex*c_ex*over_sigma_ex2/pi;
para_in = c_in*c_in*over_sigma_in2/pi;

X2 = X.*X;
Y2 = Y.*Y;
for y=1:length(Y)
    for x=1:length(X)
        %T(y,x) = DOG(c_ex, sigma_ex, X(x), Y(y)) - DOG(c_in, sigma_in, X(x), Y(y));
        X2Y2 = X2(x)+Y2(y);
        T(y,x) = para_ex*exp(-over_sigma_ex2*X2Y2) - para_in*exp(-over_sigma_in2*X2Y2);
    end
end

%size(X), size(T)
%figure(1);  mesh(X,Y,T);

return;


function d = DOG(c,sigma,x,y)
sigma2 = sigma.*sigma;
d = 0.5*(c.*c)/(pi*sigma2) * exp( - 0.5*(x.*x+y.*y)/sigma2 );

