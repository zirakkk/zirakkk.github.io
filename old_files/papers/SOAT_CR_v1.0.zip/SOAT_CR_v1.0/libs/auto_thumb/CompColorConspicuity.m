function imRes = CompColorConspicuity( imIn )

    %clear all; imIn = imread('17.jpg');

    MAXLEVEL   = 8;

    im = double(imIn)/255.0;
    r=im(:,:,1); g=im(:,:,2); b=im(:,:,3);
    R=r-(g+b)/2; G=g-(r+b)/2; B=b-(r+g)/2; Y=(r+g)/2-abs(r-g)/2-b;
    R=max(R,0);  G=max(G,0);  B=max(G,0);  Y=max(Y,0);

    %-Calculate Pyramids
    YP = GaussianPyramid( Y, MAXLEVEL );
    RP = GaussianPyramid( R, MAXLEVEL );
    GP = GaussianPyramid( G, MAXLEVEL );
    BP = GaussianPyramid( B, MAXLEVEL );

    %-Calculate color contrasts
    count = 6;
    imRG  = cell(1,count);
    imBY  = cell(1,count);
    ii    = 1;
    for c=2:4
        for s=3:4
            szTmp = size(RP{c});
            imRG{ii} = abs( (RP{c}-GP{c}) - imresize( GP{c+s}-RP{c+s}, szTmp, 'nearest'));
            imBY{ii} = abs( (BP{c}-YP{c}) - imresize( YP{c+s}-BP{c+s}, szTmp, 'nearest'));

            %figure(10); subplot(4,count,2*ii-1); imshow(imRG{ii}); Title('Before Inhibition');
            %figure(10); subplot(4,count,2*(ii+count)-1); imshow(imBY{ii}); Title('Before Inhibition');
            imRG{ii} = SurroundInhibit( imRG{ii}, 10 );
            imBY{ii} = SurroundInhibit( imBY{ii}, 10 );
            %figure(10); subplot(4,count,2*ii); imshow(imRG{ii}); Title('After Inhibition');
            %figure(10); subplot(4,count,2*(ii+count)); imshow(imRG{ii}); Title('After Inhibition');
            ii = ii+1;
        end
    end


    %-Combine contrasts into color conspicuity
    sz = round(size(R)/4);
    conRG = zeros(sz);    conBY = zeros(sz);
    for ii=1:count
        conRG = conRG + imresize(imRG{ii},sz,'nearest');
        conBY = conBY + imresize(imBY{ii},sz,'nearest');
    end

    conRG = conRG / count;
    conBY = conBY / count;
    imRes = 0.5*(conRG+conBY);
    imRes = Scale(imRes, 0, 1);
    return;

    %------------------------------------------------------
    % Following code is for debug only, no use now
    figure(7); clf;
    subplot(2,2,1);     imshow(im);         title 'Original'
    subplot(2,2,2);     imshow(conRG);      title 'RG'
    subplot(2,2,3);     imshow(conBY);      title 'BY'
    subplot(2,2,4);     imshow(imRes);      title 'Color Contrast'