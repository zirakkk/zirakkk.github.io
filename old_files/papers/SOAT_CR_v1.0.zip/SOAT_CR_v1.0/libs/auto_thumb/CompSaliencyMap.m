% function [imIContr, imCContr, imOContr, imSaliency] = CompSaliencyMap(im)

function [imIContr, imCContr, imOContr, imSaliency] = CompSaliencyMap(im)

    %-Resize inputed image to proper size
    sz = size(im); sz = sz(1:2);
    szMax = max(sz);    szMin = min(sz);
    if szMin < 128
        ratio = 128.0 / szMin;
        szInput = round(sz*ratio);
        imInput = imresize(im, szInput, 'bilinear');
    elseif szMax > 512
        ratio = 512 / szMax;
        szInput = round(sz*ratio);
        imInput = imresize(im, szInput, 'bilinear');
    else
        imInput = im;
    end

    %-Compute three conspicuity maps
    imIContr = CompIntensityConspicuity( imInput );
    imCContr = CompColorConspicuity( imInput );
    imOContr = CompOrientationConspicuity( imInput );

    %size(imIContr),size(imCContr),size(imOContr)
    imSaliency = (imIContr+imCContr+imOContr)/3.0;
    imSaliency = Scale(imSaliency,0,1);

    %imSaliency = SurroundInhibit( imSaliency, 10 );

