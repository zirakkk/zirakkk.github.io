function imRes = Scale(im,a,b)
%--------------------------------------
% function imRes = Scale(im,a,b)
%--------------------------------------

btm = min(min(im));
top = max(max(im));
if abs(btm-top)<=0.000001
    %btm    top
    imRes = im;
    return
end

dbScale = (b-a)/(top-btm);
imRes = (im-btm) * dbScale + a;

return;