%	function [imout] = auto_thumbnail(imin, iFigure)
%
% 	This function takes imin as the input image and returns imout as the cropped image 
% 		which is to be shrinked to a thumbnail.
%	if iFigure>0, then demo result in the figure with id iFigure
% 
% 	The basic idea is to first compute the saliency map of the given image, then cropping 
% 		the image to contain as more saliency value as possible while with as small size as 
%		possible. 
%
%	Author: Haibin Ling (hbling@cs.umd.edu)
%			Department of Computer Science, University of Maryland, College Park
%			Dec. 2002
%

function [imout] = auto_thumbnail(imin, iFigure, ImportanceIm)
	if ~exist('imin')		imin=imread('AS0100.jpg');	end
	if ~exist('iFigure')	iFigure = 1;				end		
	
	% compute saliency map
% 	[imIContr, imCContr, imOContr, imSaliency] = CompSaliencyMap(imin);
	sz=round((size(imin)/4));
    ImportanceIm=imresize(ImportanceIm,[sz(1) sz(2)]);
    imSaliency=[];
    imSaliency=double(ImportanceIm);

	% crop input image
	cropType	= 1;		% 0:bruce force, 1:heuristic
	threshold	= -1;		% if <0, then automatically determine the threshold
	searchType	= 2;		% 0:demo, 1:gradient, 2:binary
	bKeepRatio	= 1;
	incrEdge	= [.02,.02,.02,.02];

	cropFormat  = 0;		% 0: clipping out and get the thumbnail			for demo use only
				          	% 1: let the surround be black
				          	% 2: draw a white line along the clipping rectangle
				          	% 3: let the surround be darker

	[imout, imIconSali] = thumb_crop(...
								imin, ...
								imSaliency,	...		% saliency map of input image imin
                                cropType, ...   	% 0:bruce force, 1:heuristic
                                threshold, ...		% if <0, then automatically determine the threshold
                                searchType, ... 	% 0:demo, 1:gradient, 2:binary
                                bKeepRatio, ...
                                incrEdge,...             
                                cropFormat, ...
                                iFigure);			% demo in this figure (if > 0)					for demo use only

return
