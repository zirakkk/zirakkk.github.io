function gaussPyr = GaussianPyramid( im, MAXLEVEL )
%--------------------------------------------------------------------
%   Calculate intensity pyramid
%   
%   im       : the input image, the pixel value is in [0.0, 1.0] !!
%   MAXLEVEL : to control how many diffirent level of resolutions 
%              we try to use to get the average intensity contrast
%
%  function imRes = GaussianPyramid( im, MAXLEVEL )
%--------------------------------------------------------------------

sz = size(im);

gaussPyr = cell(1,MAXLEVEL);

gaussOp = [1 2 1; 2 4 2; 1 2 1]/16.0;
gaussPyr{1}=im;
imPrev = gaussPyr{1};

for level=2:MAXLEVEL
    sz      = size(imPrev);
    imNew   = conv2(imPrev, gaussOp);
    imNew   = imNew(2:1+sz(1), 2:1+sz(2));
	imNew(:,1) = imNew(:,2);    imNew(:,sz(2)) = imNew(:,sz(2)-1);
	imNew(1,:) = imNew(2,:);    imNew(sz(1),:) = imNew(sz(1)-1,2);    
    
    imNew = imresize( imNew, sz/2, 'nearest' );
    gaussPyr{level} = imNew;
    imPrev = imNew;
    
    %figure(2);imTmpShow=Scale(imPrev,0,1);subplot(3,3,level),imshow(gaussPyr{level});   % showing middle result
end

return;

for level=2:MAXLEVEL
    [nY,nX] = size(imPrev);
    imTmp   = zeros(nY+2,nX+2);
    imTmp(2:1+nY,2:1+nX) = imPrev;
    imTmp(1,:)   = imTmp(2,:);      imTmp(2+nY,:)= imTmp(1+nY,:);
    imTmp(:,1)   = imTmp(:,2);      imTmp(:,2+nX)= imTmp(:,1+nX);
    
    imNew   = conv2(imTmp, gaussOp);
    imNew   = imNew(3:2+nY, 3:2+nX);

    imNew = imresize( imNew, [nY,nX]/2, 'nearest' );
    gaussPyr{level} = imNew;
    imPrev = imNew;
    
    %figure(2);imTmpShow=Scale(imPrev,0,1);subplot(3,3,level),imshow(gaussPyr{level});   % showing middle result
    clear imTmp,imNew;
end

return