% function imSaliencyEx = PostProcesSaliencyMap(imSaliency);

function imRes = PostProcesSaliencyMap(imSaliency)

	imRes = imSaliency;

	%-- inhibit edge pixels
	[nY,nX]=size(imRes);
	edgeY = max(round(nY/20),2);
	edgeX = max(round(nX/20),2);

    mask = ones(nY,nX);

if 1
	mask(1:edgeY,:)=0;              % Clear the margins
	mask(nY-edgeY+1:nY,:)=0;
	mask(:, 1:edgeX)=0;
	mask(:, nX-edgeX+1:nX)=0;
    for x = edgeX+1 : edgeX+edgeX
        %val = sqrt((x-edgeX)/edgeX);
        val = (x-edgeX)/edgeX;
        mask(:,x) = val * mask(:,x);
        mask(:,nX-x+1) = val * mask(:,nX-x+1);
    end
    
    for y = edgeY+1:edgeY+edgeY
        val = sqrt((y-edgeY)/edgeY);
        mask(y,:) = val * mask(y,:);
        mask(nY-y+1,:) = val * mask(nY-y+1,:);
    end
    
else
    
    for x = 1:edgeX
        val = x/edgeX;
        mask(:,x) = val * mask(:,x);
        mask(:,nX-x+1) = val * mask(:,nX-x+1);
    end
    
    for y = 1:edgeY
        val = y/edgeY;
        mask(y,:) = val * mask(y,:);
        mask(nY-y+1,:) = val * mask(nY-y+1,:);
    end
end

    imRes = imRes.*mask;
    imRes = imRes.^2;
    
	%minThre = 0.1;    threMask = imRes > minThre;    imRes = imRes.*threMask;
    
return;

	%-- Use the distance as weight
	cY=nY/2;  cX=nX/2;
	maxDist = 0.5*sqrt(nY*nY+nX*nX);
	for y=1:nY
		for x=1:nX
			dist   = sqrt((y-cY)^2+(x-cX)^2);
			weight = 1 - dist/maxDist;
			imRes(y,x) = imRes(y,x) * weight;
		end
	end
	imRes = Scale(imRes,0,1);
