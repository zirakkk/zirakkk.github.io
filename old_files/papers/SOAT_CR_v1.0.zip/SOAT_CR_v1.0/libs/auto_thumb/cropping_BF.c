#include "mex.h"

bool bDebug=false;

/*---------------------------------------------------------------------*/
double MAT(double *pMat, int M, int N, int y, int x)
{
    return *(pMat+x*M+y);
}

/*---------------------------------------------------------------------*/
double sum(double *pData, int M, int N, 
             int yStart, int yEnd, int xStart, int xEnd)
{
    double  res, *pCur;
    int x,y;
    res = 0.0;

    for(x=xStart; x<=xEnd; x++){
        pCur = pData + x*M + yStart;
        for(y=yStart; y<=yEnd; y++){
            res += *pCur;
            pCur++;
        }
    }

    return res;
}

/*---------------------------------------------------------------------*/
double sumEx(double *pAuxSum, int M, int N, 
             int yStart, int yEnd, int xStart, int xEnd)
{
    double  res;
    res = *(pAuxSum+yEnd+M*xEnd);

    if( yStart>yEnd || yEnd>=M || yStart<0 ||
        xStart>xEnd || xEnd>=N || xStart<0 ) 
    {
        printf("Error boundary! Cropping_BF.dll, function sumEx()\n");
        printf(".........in sumEx..... %d %d %d %d", yStart, yEnd, xStart, xEnd);
    }

    if(yStart!=0 && xStart!=0)    {
        res = res + *(pAuxSum + yStart-1 + M*(xStart-1))
                  - *(pAuxSum + yEnd     + M*(xStart-1))
                  - *(pAuxSum + yStart-1 + M*xEnd);
    }
    else if(yStart==0 && xStart!=0)  {
        res -= *(pAuxSum+yEnd+M*(xStart-1));
    }
    else if(xStart==0 && yStart!=0)  {
        res -= *(pAuxSum+yStart-1+M*xEnd);
    }

    //if(bDebug)      printf(".....out sumEx\n");
    return res;
}

/*---------------------------------------------------------------------*/
void Cropping_BF(double *pSali, double *pAuxSum,
                 double dRatio, int M, int N, 
                 double *pXRange, double *pYRange,
                 double dInitArea)
{
    int     optXStart, optXEnd, optYStart, optYEnd;
    int     nStartX, nStartY, nEndX, nEndY;
    double  minArea, sumThreshold, curSum, tmpSum;
    bool    bNewResult;
    
    /* Initialize results   */
    optXStart = 0;      optXEnd   = N-1;
    optYStart = 0;      optYEnd   = M-1;
    bNewResult = false;
    minArea = dInitArea<=0.1 ? M*N : dInitArea;
    sumThreshold = sumEx(pAuxSum, M, N, 0, M-1, 0, N-1) * dRatio;

    /* Search for new result, cornered at (nStartX,nStartY) */
    for(nStartY=1; nStartY<M-1; nStartY++)
    {
        /*printf("%3d/%d \n", nStartY, M);*/
        for(nStartX=1; nStartX<N-1; nStartX++)
        {
            bNewResult = false;

            for(nEndY=nStartY+1; nEndY<M; nEndY++)
            {
                nEndX = (int)(minArea/(nEndY-nStartY+1)) + nStartX - 1;
                if(nEndX>=N)   nEndX = N-1;

                curSum = sumEx(pAuxSum, M,N, nStartY,nEndY,nStartX,nEndX);
                while (curSum>sumThreshold)   
                {
                    if(nEndX<=nStartX) { 
                        printf("Error!!  thre=%5.2lf\n", sumThreshold);
                        break;
                    }

                    bNewResult  = true;
                    optXEnd     = nEndX;
                    optYEnd     = nEndY;

                    nEndX       = nEndX-1;
                    curSum      = sumEx(pAuxSum, M,N, nStartY,nEndY,nStartX,nEndX);
                }
            
                if(bNewResult)  {
                    optXStart = nStartX;
                    optYStart = nStartY;
                    minArea = (optXEnd-optXStart+1)*(optYEnd-optYStart+1);
                }
            }
        }
    }

    /* return result */
    pXRange[0] = optXStart+1;
    pXRange[1] = optXEnd+1;
    pYRange[0] = optYStart+1;
    pYRange[1] = optYEnd+1;
}


/*---------------------------------------------------------------------*/
void Cropping_BF_KeepRatio(
                 double *pSali, double *pAuxSum,
                 double dRatio, int M, int N, 
                 double *pXRange, double *pYRange,
                 double dInitArea)
{
    int     optXStart, optXEnd, optYStart, optYEnd;
    int     nStartX, nStartY, nEndX, nEndY;
    int     nDeltaX, nDeltaY, nYMin, nYMax;
    double  dWHRatio;
    double  minArea, sumThreshold, curSum, tmpSum;
    bool    bNewResult;
    
    /* Initialize results   */
    optXStart = 0;      optXEnd   = N-1;
    optYStart = 0;      optYEnd   = M-1;
    /*minArea  = dInitArea<=0.1 ? M*N : dInitArea;   */
    minArea    = M*N;
    sumThreshold = sumEx(pAuxSum, M, N, 0, M-1, 0, N-1) * dRatio;

    dWHRatio = N/(double)M;

    /* Search for new result, cornered at (nStartX,nStartY) */
    for(nStartY=1; nStartY<M-1; nStartY++)
    {
        /*printf("%3d/%d \n", nStartY, M);*/
        for(nStartX=1; nStartX<N-1; nStartX++)
        {
            bNewResult = false;
            for(nEndY=nStartY+1; nEndY<M && !bNewResult; nEndY++)
            {
                nDeltaY = (nEndY-nStartY+1);
                nDeltaX = (nEndY-nStartY+1)*N/M;
                if(nDeltaX*nDeltaY>=minArea)   break;

                nEndX   = nStartX+nDeltaX-1;
                if(nEndX>=N)        {
                    nEndX = N-1;
                    /*  printf("\nERROR! nEndX=%d >= N=%d\n",nEndX,N);break;    */
                }
                if(nEndX<=nStartX)  {
                    nEndX=nStartX+1;
                    /*printf("\nERROR! nEndX=%d <= nStartX=%d\n",nEndX,nStartX);break;  */
                }

                curSum = sumEx(pAuxSum, M,N, nStartY,nEndY,nStartX,nEndX);
                //printf("after sumEx..... %d %d %d %d\n", nStartY, nEndY, nStartX, nEndX);
                if (curSum>sumThreshold)   
                {
                    if(nEndX<=nStartX) { 
                        printf("Error!!  thre=%5.2lf\n", sumThreshold);
                        break;
                    }

                    bNewResult  = true;
                    optXStart   = nStartX;
                    optYStart   = nStartY;
                    optXEnd     = nEndX;
                    optYEnd     = nEndY;
                    minArea     = nDeltaX*nDeltaY;
                }
            }
        }
    }

    /* return result */
    pXRange[0] = optXStart+1;
    pXRange[1] = optXEnd+1;
    pYRange[0] = optYStart+1;
    pYRange[1] = optYEnd+1;
}

/*---------------------------------------------------------------------*/
double* CreateAuxSum(double *pSali, int M, int N)
{
    double* pRes=(double*)malloc(M*N*sizeof(double));
    int y,x;
    memcpy(pRes,pSali,M*N*sizeof(double));

    if(bDebug)      printf("Create AuxSum matrix.\n");

    /*
    for(y=0;y<M;y++)    {
        for(x=0;x<N;x++){
            *(pRes+x*M+y) = sum(pSali,M,N,0,y,0,x);
        }
    }
    /*/
    for(y=1;y<M;y++)    {
        for(x=0;x<N;x++){
            *(pRes+x*M+y) = *(pRes+x*M+y) + *(pRes+x*M+y-1);
        }
    }

    for(x=1;x<N;x++)    {
        for(y=0;y<M;y++){
            *(pRes+x*M+y) = *(pRes+x*M+y) + *(pRes+(x-1)*M+y);
        }
    }

    return pRes;
}


/*-----------------------------------------------------------------------
     [XRange, YRange] = Cropping_BruceForce(
                            pSali, 
                            ratio, 
                            auxSum, 
                            dInitArea,
                            bKeepRatio
                            )
 ------------------------------------------------------------------------*/
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    mxArray *pMxSali, *pMxRatio, *pMxAuxSum, *pMxTest, *pMxInitArea, *pMxKeepRatio;
    mxArray *pMxXRange, *pMxYRange;
    double *pSali, *pRatio, dRatio, *pAuxSum, *pTest, *pInitArea, dInitArea;
    double *pXRange, *pYRange;
    int bKeepRatio;
    int M,N;
    int i,M1,N1,x,y;

    /* Prepare for the data */
    pMxSali     = prhs[0];
    pSali       = mxGetPr(pMxSali);
    M           = mxGetM(pMxSali);
    N           = mxGetN(pMxSali);
    pMxRatio    = prhs[1];
    pRatio      = mxGetPr(pMxRatio);
    dRatio      = *pRatio;
    
    if(nrhs>=3) {
        pMxAuxSum   = prhs[2];
        pAuxSum     = mxGetPr(pMxAuxSum);
    }
    else    {
        if(bDebug)  printf("Missing auxSum as parameter!\n");
        pAuxSum = CreateAuxSum(pSali, M, N);
    }

    dInitArea   = M*N;  
    if(nrhs>=4) {
        pMxInitArea = prhs[3];
        pInitArea   = mxGetPr(pMxInitArea);
        dInitArea   = *pInitArea;
        if(dInitArea<=0.001)
            dInitArea = M*N;
    }
    else    {
        if(bDebug)  printf("Missing dInitArea as parameter!\n");
        dInitArea   = M*N;
    }

    bKeepRatio = 0;
    if(nrhs>=5) {
        pMxKeepRatio = prhs[4];
        bKeepRatio   = *mxGetPr(pMxKeepRatio);
    }

    /* Create output matrices */
    pMxXRange = mxCreateDoubleMatrix(1,2,mxREAL);
    pMxYRange = mxCreateDoubleMatrix(1,2,mxREAL);
    pXRange   = mxGetPr(pMxXRange);
    pYRange   = mxGetPr(pMxYRange);

    /* Cropping */
    if(bKeepRatio==0)
        Cropping_BF(pSali, pAuxSum, dRatio, M, N, pXRange, pYRange, dInitArea);
    else
        Cropping_BF_KeepRatio(pSali, pAuxSum, dRatio, M, N, pXRange, pYRange, dInitArea);
    
    if(nrhs<3)
        free(pAuxSum);

    /* Return */
    plhs[0] = pMxXRange;
    plhs[1] = pMxYRange;
}

