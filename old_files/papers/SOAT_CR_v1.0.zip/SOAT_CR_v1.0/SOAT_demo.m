% function SOAT_demo
% Demo program for SOAT framework, including SOAS computation and SOAT
% Thumbnail transform function (SOAT_methods)
%
% Jin Sun
% Temple University
% 2011

function SOAT_demo

clc;
clear;
close all;

% update path for extenal libraries
addpath('libs/Saliency/simpsal');
addpath('libs/auto_thumb');

objectness_path=[pwd '/libs/objectness-release-v1.5'];
addpath(objectness_path);
addpath([objectness_path '/MEX/']);

%%%%%%%%%%%% Params %%%%%%%%%%%%% 
% thumbnail size
TARGET_X=50;
TARGET_Y=50;
% method choice
SOAT_method='CR';
% SOAS params
ViewingPixelInImage_X=50;%thumbnail size shown on screen in pixel
ViewingPixelInImage_Y=50;
ViewDistance=0.5;


% read image
s_img = 'bike.jpg';

display('SOAT - Scale and Object Aware Thumbnailing');
display(['Start processing image: ' s_img]);


I=imread(s_img);
[y,x,z]=size(I);
if y>TARGET_Y && x>TARGET_X % if target scale is smaller

    SOAS(I,ViewingPixelInImage_X,ViewingPixelInImage_Y,ViewDistance,objectness_path);
    
    tic
    SOAT_methods(I,TARGET_X,TARGET_Y,SOAT_method);
    t=toc;

    display(['Finish! Total time: ',num2str(t),'s']);

else
    display('Image width/height is less than target scale.');
    
end