% ----------------------------------------------------------------
% function fI_csf_saliency=SOAS_csfFilter(
%                       Iori,                          .... Input image
%                       ViewingPixelInImage_X,      .... Thumbnail width shown on screen in pixel
%                       ViewingPixelInImage_Y,      .... Thumbnail height shown on screen in pixel                  
%                       ViewDistance)               .... Viewing distance
%                                                         
% 
% This function applies csf filter.
% 
% Jin Sun
% Temple University
% 2011
% Revised: 1/2013, Jin Sun
% ----------------------------------------------------------------


function fI_csf_saliency=SOAS_csfFilter(Iori,ViewingPixelInImage_X,ViewingPixelInImage_Y,ViewDistance)


%%%%%% Parameters
if nargin<2
ViewDistance=1;
ViewingPixelInImage_X=100;
ViewingPixelInImage_Y=100;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%
Iori=rgb2gray(Iori);%Iori expected to be color image
OriginalSize=size(Iori(:,:));
% flags to tell whether images has been shrinked before applied to filter
width_shrinked=0;
height_shrinked=0;

if mod(length(Iori(:,1)),2)==0
    Ioriginal(:,:)=Iori(1:end-1,:);
    height_shrinked=1;
else
    Ioriginal=Iori;
end
if mod(length(Iori(1,:)),2)==0
    Ioriginal(:,1:end-1)=Iori(1:length(Ioriginal(:,1)),1:end-1);
    Ioriginal(:,end)=[];
    width_shrinked=1;
else
    Ioriginal(:,:)=Iori(1:length(Ioriginal(:,1)),1:end,:);
end
AdaptSize=size(Ioriginal);

ViewingPixelInImage=[ViewingPixelInImage_X ViewingPixelInImage_Y];


degree=myVisualDegree(ViewDistance,ViewingPixelInImage);%calculate viewing angle given viewing distance and pixels
csf=myCSFCurve(AdaptSize,degree);


fI_csf_filted=fftshift(fft2(Ioriginal)).*csf;
fI_show=real(ifft2(ifftshift(fI_csf_filted)));

newfI_show=zeros(OriginalSize(1),OriginalSize(2));
newfI_show(1:OriginalSize(1)-height_shrinked,1:OriginalSize(2)-width_shrinked)=fI_show;

% two saliency implementations can be selected
% 1. simpsal implementation
fI_csf_saliency = simpsal(uint8(newfI_show));
% 2. auto_thumb implementation
% [imIContr, imCContr, imOContr, fI_csf_saliency] = CompSaliencyMap(newfI_csf);
fI_csf_saliency = mat2gray(imresize(fI_csf_saliency,[OriginalSize(1) OriginalSize(2)]));

end



% CSF Curve shape
function csf=myCSFCurve(OriginalSize,degree)
% canonical csf model
csfM=100;
[x,y]=meshgrid(-csfM/2:1:csfM/2);
csf= 2.6 * (0.0192 + 0.114* sqrt(x.^2+y.^2) ).* exp(-(0.114* sqrt(x.^2+y.^2)).^1.1);

% map to new model given viewing degree
csfY=ceil(csfM*degree(1));% new model y
csfX=ceil(csfM*degree(2));% new model x
if mod(csfY,2)==0
   csfY=csfY-1;
end
if mod(csfX,2)==0
   csfX=csfX-1;
end

csf=imresize(csf,[csfY csfX]);

% now adapt to image size
csf_bak=csf;csf=[];

M1=OriginalSize(1);
M2=OriginalSize(2);


canvas=zeros(max(csfY,M1),max(csfX,M2));
[canvas_height canvas_width]=size(canvas);

csf_width=(length(csf_bak(1,:))-1)/2;
csf_height=(length(csf_bak(:,1))-1)/2;

canvas((canvas_height+1)/2-csf_height:(canvas_height+1)/2+csf_height,(canvas_width+1)/2-csf_width:(canvas_width+1)/2+csf_width)=csf_bak;
csf=canvas((canvas_height+1)/2-(M1-1)/2:(canvas_height+1)/2+(M1-1)/2,(canvas_width+1)/2-(M2-1)/2:(canvas_width+1)/2+(M2-1)/2);

    
%DC term    
csf((M1+1)/2,(M2+1)/2)=1;
end

% function calculate viewing degree, view at 1m, 200px image size on monitor becomes 60px
function degree=myVisualDegree(ViewDistance,ImageSizeInPixel)
% % % % % % % % % % Horizon
S=ImageSizeInPixel(1)*0.0084;%0.0084 inch/dot, adjust here for specific monitor
D=ViewDistance*39.37;
degree1 = 2*atan(S/(2*D));
degree1 = degree1*180/pi;

% % % % % % % % % % Vertical
S=ImageSizeInPixel(2)*0.0084;%0.0084 inch/dot, adjust here for specific monitor
D=ViewDistance*39.37;
degree2 = 2*atan(S/(2*D));
degree2 = degree2*180/pi;

degree=[degree1 degree2];

end
