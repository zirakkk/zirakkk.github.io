DT-OC5 Dataset (Delaware-Temple OC5 Dataset)

2010/12

This dataset contains objects from 5 categories: car, cow, cup, dog and horse. Each category contains 6 different objects. Each objects were photographed with 4 poses:0, 90, 180, 270 rotating from default pose. You can find corresponding OC data in "OC" subdirectories in every category directories.

This dataset is affiliated with the paper:

Category Classification Using Occluding Contours
Jin Sun, Christopher Thorpe, Nianhua Xie, Jingyi Yu, and Haibin Ling
6th Int. Symposium on Visual Computing (ISVC), 2010. 